import customtkinter as ctk
from tabs.ping_tab import PingTab
from tabs.tracert_tab import TracertTab
from tabs.public_ip_tab import PublicIPTab
from tabs.speedtest_tab import SpeedtestTab
from tabs.ip_settings_tab import IPSettingsTab
from tabs.port_offen_tab import PortTesterTab

class NetworkToolsApp(ctk.CTk):
    def __init__(self,is_admin=False):
        super().__init__()

        self.is_admin = is_admin

        self.title("Netzwerk Tools" + (" (Admin)" if self.is_admin else " (Eingeschränkt)")) # Titel anpassen
         # Startgröße anpassen

        # Fenster zentrieren (optional)
        self.center_window()

        self.iconbitmap(r"d:\Downloads\Python\nt\icon.ico") # Icon setzen (Pfad anpassen)


        # --- Theme-Einstellungen ---
        ctk.set_appearance_mode("Light")  # Oder "System","Light", "Dark"
        ctk.set_default_color_theme("blue") # Oder "green", "dark-blue"

        # --- Hauptlayout ---
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # --- TabView erstellen ---
        self.tab_view = ctk.CTkTabview(self)
        self.tab_view.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")

        # --- Tabs hinzufügen ---
        self.tab_view.add("IP Profile")
        self.tab_view.add("Ping")
        self.tab_view.add("Traceroute")
        self.tab_view.add("Öffentliche IP")
        self.tab_view.add("Speedtest")
        self.tab_view.add("Port offen")
        

        # --- Tab-Inhalte erstellen und platzieren ---
        self.ip_settings_frame = IPSettingsTab(master=self.tab_view.tab("IP Profile"), is_admin=self.is_admin)
        self.ip_settings_frame.pack(expand=True, fill="both")


        self.ping_frame = PingTab(master=self.tab_view.tab("Ping"))
        self.ping_frame.pack(expand=True, fill="both")

        self.tracert_frame = TracertTab(master=self.tab_view.tab("Traceroute"))
        self.tracert_frame.pack(expand=True, fill="both")

        self.public_ip_frame = PublicIPTab(master=self.tab_view.tab("Öffentliche IP"))
        self.public_ip_frame.pack(expand=True, fill="both")

        self.speedtest_frame = SpeedtestTab(master=self.tab_view.tab("Speedtest"))
        self.speedtest_frame.pack(expand=True, fill="both")

        self.port_offen_frame = PortTesterTab(master=self.tab_view.tab("Port offen"))
        self.port_offen_frame.pack(expand=True, fill="both")



        # Standard-Tab setzen (optional)
        self.tab_view.set("IP Profile")


    def center_window(self):
        """Zentriert das Fenster auf dem Hauptbildschirm."""
        self.update_idletasks() # Aktualisiert die Fenstergeometrie
        width = self.winfo_width()
        height = self.winfo_height()
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)
        self.geometry(f'{width}x{height}+{x}+{y}')