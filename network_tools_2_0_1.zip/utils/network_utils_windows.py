# utils/network_utils_windows.py
import subprocess
import re

# --- Hilfsfunktionen zum Ausführen von netsh ---
def _run_command(command):
    """Führt einen Befehl aus und gibt stdout, stderr und returncode zurück."""
    try:
        # Verwende CREATE_NO_WINDOW, um Konsolenfenster zu unterdrücken
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        creationflags = subprocess.CREATE_NO_WINDOW

        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            encoding='cp850', # Oft die Codierung der deutschen Konsole, anpassen bei Bedarf!
            errors='ignore',
            check=False, # Wir prüfen den Returncode manuell
            startupinfo=startupinfo,
            creationflags=creationflags
        )
        # print(f"Befehl: {' '.join(command)}") # Debugging
        # print(f"Returncode: {result.returncode}") # Debugging
        # print(f"Stdout: {result.stdout}") # Debugging
        # print(f"Stderr: {result.stderr}") # Debugging
        return result.stdout, result.stderr, result.returncode
    except FileNotFoundError:
        return None, f"Fehler: Befehl '{command[0]}' nicht gefunden.", -1
    except Exception as e:
        return None, f"Fehler beim Ausführen von '{' '.join(command)}': {e}", -1

# --- Funktionen zum Auslesen ---

def get_active_adapters_windows():
    """ Gibt eine Liste von Namen verbundener Netzwerkadapter zurück (Windows). """
    adapters = []
    # 'netsh interface show interface' zeigt Admin-Status, Zustand, Typ, Name
    stdout, stderr, code = _run_command(['netsh', 'interface', 'show', 'interface'])
    if code == 0 and stdout:
        # Vorsichtiges Parsen - Annahme: Name ist die letzte Spalte nach mehreren Leerzeichen
        # Und Zustand ist 'Verbunden' oder 'Connected'
        lines = stdout.splitlines()
        for line in lines[3:]: # Kopfzeilen überspringen
            parts = line.split()
            if len(parts) >= 4:
                # Zustand ist oft die zweite oder dritte Spalte
                status = parts[1] if parts[1].lower() in ['verbunden', 'connected'] else parts[2] if len(parts) > 2 and parts[2].lower() in ['verbunden', 'connected'] else None
                if status:
                    # Name kann Leerzeichen enthalten, also alles ab der 4. Spalte
                    adapter_name = " ".join(parts[3:]).strip()
                    if adapter_name:
                        adapters.append(adapter_name)
    elif stderr:
         print(f"Fehler beim Abrufen der Adapter: {stderr}")
    return adapters


# utils/network_utils_windows.py
import subprocess
import re

# ... (_run_command bleibt gleich) ...

def get_ip_config_windows(adapter_name):
    """ Ruft die IP-Konfiguration für einen Adapter ab (Windows). Gibt ein Dict zurück. """
    config = {"ip": "", "subnet": "", "gateway": "", "dns": [], "dhcp_enabled": False}
    stdout, stderr, code = _run_command(['netsh', 'interface', 'ip', 'show', 'config', f'name={adapter_name}'])

    if code != 0 or not stdout:
        print(f"Fehler beim Abrufen der Konfig für '{adapter_name}': {stderr or 'Keine Ausgabe'}")
        return config

    lines = stdout.splitlines()
    current_dns = []
    
    for line in lines:
        stripped_line = line.strip()
        if not stripped_line:
            continue

        # DHCP-Status
        if re.search(r"^DHCP aktiviert:\s*Ja", stripped_line, re.IGNORECASE):
            config["dhcp_enabled"] = True

        # Subnetzmaske aus Klammern extrahieren (neuer Fall)
        if "Subnetzpräfix" in line and "Maske" in line:
            mask_match = re.search(r"Maske (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\)", line)
            if mask_match:
                config["subnet"] = mask_match.group(1)

        # IP-Adresse
        ip_match = re.search(r"^IP-Adresse:\s*(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})", stripped_line, re.IGNORECASE)
        if ip_match and not config["ip"]:
            config["ip"] = ip_match.group(1)

        # Gateway
        gw_match = re.search(r"^Standardgateway:\s*(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})", stripped_line, re.IGNORECASE)
        if gw_match and gw_match.group(1) != "0.0.0.0":
            config["gateway"] = gw_match.group(1)

        # DNS-Server (mit deutschem Label)
        dns_match = re.search(r"DNS-Server:\s*(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})", stripped_line, re.IGNORECASE)
        if dns_match:
            current_dns.append(dns_match.group(1))

    config["dns"] = current_dns
    return config

# ... (Rest der Datei: set_dhcp_windows, set_static_ip_windows, etc. bleiben gleich) ...

# --- Funktionen zum Setzen ---

def set_dhcp_windows(adapter_name):
    """ Stellt einen Adapter auf DHCP um (IP und DNS). """
    print(f"Versuche DHCP für '{adapter_name}' zu setzen...")
    cmd_ip = ['netsh', 'interface', 'ip', 'set', 'address', f'name={adapter_name}', 'source=dhcp']
    cmd_dns = ['netsh', 'interface', 'ip', 'set', 'dns', f'name={adapter_name}', 'source=dhcp']

    out_ip, err_ip, code_ip = _run_command(cmd_ip)
    out_dns, err_dns, code_dns = _run_command(cmd_dns)

    success = code_ip == 0 and code_dns == 0
    errors = []
    if code_ip != 0: errors.append(f"IP-Fehler: {err_ip or out_ip}")
    if code_dns != 0: errors.append(f"DNS-Fehler: {err_dns or out_dns}")

    return success, "\n".join(errors)

def set_static_ip_windows(adapter_name, ip, subnet, gateway):
    """ Setzt eine statische IP-Adresse, Subnetzmaske und Gateway. """
    print(f"Versuche statische IP für '{adapter_name}' zu setzen: {ip}/{subnet}, GW: {gateway}")
    cmd = ['netsh', 'interface', 'ip', 'set', 'address', f'name={adapter_name}', 'static', ip, subnet]
    if gateway: # Gateway nur hinzufügen, wenn vorhanden
        cmd.append(gateway)
    else:
         cmd.append("none") # Explizit kein Gateway setzen? Oder weglassen? Netsh ist hier unklar. Sicherer ist es, es mitzugeben, wenn nötig.

    stdout, stderr, code = _run_command(cmd)
    success = code == 0
    error = stderr or stdout if not success else ""
    # Manchmal gibt netsh 0 zurück, obwohl ein Fehler auftrat (z.B. IP in use) - Ausgabe prüfen?
    if success and ("fehler" in stdout.lower() or "error" in stdout.lower()):
        success = False
        error = stdout
    if success and ("fehler" in stderr.lower() or "error" in stderr.lower()): # Doppelt prüfen
        success = False
        error = stderr

    return success, error

def set_static_dns_windows(adapter_name, dns1, dns2=None):
    """ Setzt statische DNS-Server. """
    print(f"Versuche statische DNS für '{adapter_name}' zu setzen: {dns1}{', ' + dns2 if dns2 else ''}")
    cmd1 = ['netsh', 'interface', 'ip', 'set', 'dns', f'name={adapter_name}', 'static', dns1]
    out1, err1, code1 = _run_command(cmd1)
    success1 = code1 == 0
    errors = []
    if not success1: errors.append(f"DNS1 Fehler: {err1 or out1}")

    success2 = True # Standardmäßig erfolgreich, wenn kein zweiter DNS gesetzt wird
    if dns2:
        cmd2 = ['netsh', 'interface', 'ip', 'add', 'dns', f'name={adapter_name}', dns2, 'index=2']
        out2, err2, code2 = _run_command(cmd2)
        success2 = code2 == 0
        if not success2: errors.append(f"DNS2 Fehler: {err2 or out2}")
    else:
        # Optional: Entferne explizit den zweiten DNS? (komplexer)
        pass

    return success1 and success2, "\n".join(errors)