# utils/admin_check.py
import os
import ctypes
import platform

def is_admin():
    """Prüft, ob das Skript mit Administratorrechten läuft (Windows)."""
    if platform.system().lower() != "windows":
        # Auf nicht-Windows-Systemen prüfen wir auf Root (UID 0)
        try:
            return os.geteuid() == 0
        except AttributeError:
            # os.geteuid() nicht verfügbar (sehr altes Python oder ungewöhnliches OS)
            # Wir können hier nicht sicher prüfen, geben vorsichtshalber False zurück
             print("Warnung: Konnte Root-Rechte auf Nicht-Windows nicht prüfen.")
             return False # Annahme: Nicht Root
    else:
        # Windows-spezifische Prüfung
        try:
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        except AttributeError:
             print("Warnung: ctypes oder shell32 nicht verfügbar. Admin-Prüfung fehlgeschlagen.")
             return False # Fallback, wenn ctypes nicht geht