# main.py

import sys
import platform
import os

# Leite stdout/stderr um, wenn als PyInstaller-Executable im Windowed-Modus ausgeführt
# und die Streams auf None gesetzt sind.
if getattr(sys, 'frozen', False): # Prüft, ob unter PyInstaller ausgeführt
    # Nur umleiten, wenn sie wirklich None sind
    if sys.stdout is None:
        # Option 1: Ins Nirwana umleiten (keine Ausgabe)
        sys.stdout = open(os.devnull, 'w')
        # Option 2: In eine Log-Datei umleiten (zum Debuggen nützlich)
        # sys.stdout = open('stdout.log', 'a')
    if sys.stderr is None:
        # Option 1: Ins Nirwana
        sys.stderr = open(os.devnull, 'w')
        # Option 2: In eine Log-Datei
        # sys.stderr = open('stderr.log', 'a')


import ctypes # Nur für Windows benötigt
from app import NetworkToolsApp
from utils.admin_check import is_admin # Importiere unsere Prüffunktion

def run_elevated():
    """
    Versucht unter Windows, das Skript mit Administratorrechten neu zu starten.
    Gibt True zurück, wenn der Versuch gestartet wurde (Skript sollte dann beenden),
    False, wenn nicht (z.B. Fehler oder kein Windows).
    """
    if platform.system().lower() != "windows":
        return False # Eskalation nur für Windows implementiert

    try:
        # Parameter für ShellExecuteW:
        # hwnd = None (kein Elternfenster)
        # lpOperation = "runas" (um UAC-Prompt auszulösen)
        # lpFile = sys.executable (der Python-Interpreter)
        # lpParameters = ' '.join(sys.argv) (das Skript und seine Argumente)
        # lpDirectory = None (aktuelles Verzeichnis)
        # nShowCmd = 1 (SW_SHOWNORMAL)
        ret = ctypes.windll.shell32.ShellExecuteW(
            None,
            "runas",
            sys.executable,
            '"' + sys.argv[0] + '"', # Stelle sicher, dass der Skriptpfad in Anführungszeichen steht
            None,
            1 # SW_SHOWNORMAL
        )
        print(f"ShellExecuteW return code: {ret}") # Debugging
        # Wenn ShellExecuteW erfolgreich war (>=32), wurde der UAC-Dialog angezeigt
        # (oder es war nicht nötig). Das aktuelle Skript sollte sich beenden.
        return ret >= 32
    except Exception as e:
        print(f"Fehler beim Versuch, erhöhte Rechte anzufordern: {e}")
        return False


if __name__ == "__main__":
    # Prüfe, ob bereits Admin-Rechte vorhanden sind
    has_admin_rights = is_admin()

    if not has_admin_rights:
        print("Keine Administratorrechte erkannt. Versuche, Rechte anzufordern...")
        # Versuche, mit erhöhten Rechten neu zu starten (nur Windows)
        if run_elevated():
            print("Neustart mit erhöhten Rechten angefordert. Aktuelles Skript wird beendet.")
            sys.exit(0) # Beende das nicht-privilegierte Skript
        else:
            # Wenn run_elevated False zurückgibt (Fehler, kein Windows, oder UAC abgelehnt/nicht möglich)
            print("Konnte keine erhöhten Rechte erhalten oder System ist nicht Windows.")
            print("Starte im EINGESCHRÄNKTEN MODUS (Änderungen an IP-Einstellungen deaktiviert).")
            # has_admin_rights bleibt False

    else:
        print("Administratorrechte erkannt.")

    # Erstelle die App-Instanz und übergebe den Admin-Status
    app = NetworkToolsApp(is_admin=has_admin_rights)

    # Setze die Fenstergröße HIER nach der Instanziierung
    # ACHTUNG: 400x500 ist wahrscheinlich zu klein für den IP Profile Tab!
    app.geometry("600x600")

    # Bildschirmbreite ermitteln
    screen_width = app.winfo_screenwidth()

    # X-Position berechnen (mittig)
    x_position = (screen_width // 2) +200

    # Fenster positionieren (oben, mittig)
    app.geometry(f"600x600+{x_position}+50")

    # Starte die Hauptschleife
    app.mainloop()