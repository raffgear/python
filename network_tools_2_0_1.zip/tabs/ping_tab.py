# tabs/ping_tab.py

import customtkinter as ctk
import subprocess
import threading
import platform
import time


class PingTab(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(4, weight=1) # Row für Textbox angepasst (war 2)

        self.process = None
        self.ping_thread = None
        self.stop_ping_flag = threading.Event()

        # --- Populäre Ziele ---
        self.popular_targets = [
            "Populäre Ziele...", # Platzhalter
            "google.com",
            "cloudflare.com",
            "wikipedia.org",
            "8.8.8.8",       # Google DNS
            "1.1.1.1",       # Cloudflare DNS
            "9.9.9.9",       # Quad9 DNS
            "dns.google",    # Alternativ 8.8.8.8
            "quad9.net",     # Alternativ 9.9.9.9
            "localhost",
            "127.0.0.1"
        ]

        # --- Widgets ---
        self.label = ctk.CTkLabel(self, text="Ping-Tool (Live-Ausgabe)")
        # columnspan auf 2 setzen, da Buttons jetzt in Spalte 1 sind
        self.label.grid(row=0, column=0, columnspan=2, padx=10, pady=(10, 0), sticky="ew")

        # Combobox für populäre Ziele
        self.combobox_targets = ctk.CTkComboBox(
            self,
            values=self.popular_targets,
            command=self._on_combobox_select # Callback-Funktion
        )
        self.combobox_targets.set(self.popular_targets[0]) # Platzhalter setzen
        # columnspan auf 2 setzen, um die volle Breite unter dem Label zu nutzen
        self.combobox_targets.grid(row=1, column=0, columnspan=2, padx=10, pady=5, sticky="ew")

        # Eingabefeld für Host
        self.entry_host = ctk.CTkEntry(self, placeholder_text="Hostname oder IP-Adresse eingeben")
        # Row auf 2 geändert
        self.entry_host.grid(row=2, column=0, padx=10, pady=5, sticky="ew")
        self.entry_host.bind("<Return>", self.start_ping_event)
        self.entry_host.insert(0, "8.8.8.8")  # Standardwert setzen

        # Frame für Buttons
        self.button_frame = ctk.CTkFrame(self, fg_color="transparent")
        # Row auf 2 geändert, Column bleibt 1
        self.button_frame.grid(row=2, column=1, padx=10, pady=5, sticky="e")

        self.button_start = ctk.CTkButton(self.button_frame, text="Ping starten", command=self.start_ping_thread)
        self.button_start.pack(side="left", padx=(0, 5))

        self.button_stop = ctk.CTkButton(self.button_frame, text="Stopp", command=self.stop_ping, state="disabled", fg_color="red", hover_color="darkred")
        self.button_stop.pack(side="left")

        # Textbox für Ergebnisse
        self.textbox_results = ctk.CTkTextbox(self, state="disabled", wrap="word")
        # Row auf 4 geändert
        self.textbox_results.grid(row=4, column=0, columnspan=2, padx=10, pady=10, sticky="nsew")

        # Status Label
        self.status_label = ctk.CTkLabel(self, text="")
        # Row auf 5 geändert
        self.status_label.grid(row=5, column=0, columnspan=2, padx=10, pady=(0, 5), sticky="w")


    def _on_combobox_select(self, selected_value):
        """Callback, wenn ein Wert in der ComboBox ausgewählt wird."""
        # Nur aktualisieren, wenn nicht der Platzhalter ausgewählt wurde
        if selected_value != self.popular_targets[0]:
            self.entry_host.delete(0, "end")           # Bestehenden Text löschen
            self.entry_host.insert(0, selected_value)  # Neuen Wert einfügen
            # Optional: Combobox nach Auswahl wieder auf Platzhalter setzen
            # self.combobox_targets.set(self.popular_targets[0])

    def start_ping_event(self, event=None):
        self.start_ping_thread()

    def start_ping_thread(self):
        host = self.entry_host.get()
        if not host:
            self.update_output("Bitte geben Sie einen Hostnamen oder eine IP-Adresse ein.")
            return

        self.clear_output()
        self.update_output(f"--- Starte Ping für {host} ---")
        self.status_label.configure(text="Ping wird ausgeführt...")
        self.button_start.configure(state="disabled")
        self.button_stop.configure(state="normal")
        self.stop_ping_flag.clear()

        self.ping_thread = threading.Thread(target=self.run_ping_live, args=(host,), daemon=True)
        self.ping_thread.start()

    def stop_ping(self):
        if self.ping_thread and self.ping_thread.is_alive():
            self.status_label.configure(text="Stoppe Ping...")
            self.stop_ping_flag.set()
            self.after(100, self._terminate_process_if_needed)
        self.button_stop.configure(state="disabled")

    def _terminate_process_if_needed(self):
         if self.process:
             try:
                 self.process.terminate()
                 self.process.wait(timeout=1)
             except subprocess.TimeoutExpired:
                 try:
                    self.process.kill()
                    self.update_output("\n--- Ping-Prozess musste gekillt werden ---")
                 except OSError: pass
             except Exception as e:
                 print(f"Fehler beim Beenden des Ping-Prozesses: {e}")
             finally: self.process = None
         self.after(0, self.finalize_ping, "Ping gestoppt.")

    def run_ping_live(self, host):
        final_status_message = "Ping abgeschlossen."
        try:
            command = ['ping']
            startupinfo = None
            creationflags = 0 # Default für non-Windows
            if platform.system().lower() == 'windows':
                command.append('-t')
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                creationflags = subprocess.CREATE_NO_WINDOW
            command.append(host)

            self.process = subprocess.Popen(
                command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding='cp850', errors='ignore', bufsize=1,
                startupinfo=startupinfo, creationflags=creationflags
            )

            for line in iter(self.process.stdout.readline, ''):
                if self.stop_ping_flag.is_set():
                    final_status_message = "Ping durch Benutzer gestoppt."
                    # Rufen terminate direkt hier auf, um sicherzugehen, dass es versucht wird
                    if self.process:
                        try: self.process.terminate()
                        except OSError: pass # Prozess könnte schon weg sein
                    break

                if line:
                    #print(line)
                    self.after(0, self.update_output, line.strip())
                time.sleep(0.01)

            # Nach der Schleife: Prozess beenden/warten
            if self.process:
                self.process.stdout.close()
                return_code = self.process.wait()
                if return_code != 0 and not self.stop_ping_flag.is_set():
                    self.after(0, self.update_output, f"\n--- Ping mit Fehlercode beendet: {return_code} ---")
                    final_status_message = f"Ping mit Fehlercode {return_code} beendet."
                self.process = None

        except FileNotFoundError:
             self.after(0, self.update_output, "\n--- Fehler: 'ping'-Befehl nicht gefunden. Ist er im Systempfad? ---")
             final_status_message = "Fehler: 'ping' nicht gefunden."
        except Exception as e:
            if not self.stop_ping_flag.is_set():
                 self.after(0, self.update_output, f"\n--- Unerwarteter Fehler ---\n{str(e)}")
                 final_status_message = "Ping mit Fehler beendet."
            else:
                 print(f"Fehler während des Pings (möglicherweise nach Stopp): {e}")
        finally:
            # Finalisierung nur aufrufen, wenn nicht durch Stopp-Button beendet
            if not self.stop_ping_flag.is_set() or final_status_message == "Ping durch Benutzer gestoppt.":
                # Stelle sicher, dass finalize_ping nur einmal pro Lauf aufgerufen wird
                # und den korrekten Endstatus anzeigt.
                # Die Logik in _terminate_process_if_needed ruft es bereits bei Stopp auf.
                # Hier rufen wir es für den normalen Abschluss oder Fehler auf.
                 if not self.stop_ping_flag.is_set():
                    self.after(0, self.finalize_ping, final_status_message)


    def update_output(self, text):
        try:
            self.textbox_results.configure(state="normal")
            self.textbox_results.insert("end", text + "\n")
            self.textbox_results.see("end")
            self.textbox_results.configure(state="disabled")
        except Exception as e:
            print(f"Fehler beim Aktualisieren des Textfeldes: {e}")

    def clear_output(self):
        try:
            self.textbox_results.configure(state="normal")
            self.textbox_results.delete("1.0", "end")
            self.textbox_results.configure(state="disabled")
        except Exception as e:
            print(f"Fehler beim Leeren des Textfeldes: {e}")

    def finalize_ping(self, status_message="Bereit"):
        self.button_start.configure(state="normal")
        self.button_stop.configure(state="disabled") # Stop immer deaktivieren am Ende
        self.status_label.configure(text=status_message)
        self.process = None
        self.ping_thread = None
        # Stelle sicher, dass das Flag für den nächsten Lauf zurückgesetzt ist
        # Obwohl es in start_ping_thread passiert, schadet es hier nicht.
        self.stop_ping_flag.clear()


    def destroy(self):
        if self.process:
            print("PingTab wird zerstört, stoppe laufenden Ping...")
            self.stop_ping()
            # Gib etwas Zeit zum Aufräumen, bevor der Frame zerstört wird
            # Dies ist eine Heuristik, eine robustere Lösung bräuchte evtl. Warten auf Thread-Ende
            self.update() # Verarbeite ausstehende GUI-Events
            time.sleep(0.2)
        super().destroy()