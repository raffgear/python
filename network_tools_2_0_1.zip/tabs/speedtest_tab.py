# tabs/speedtest_tab.py

import customtkinter as ctk
import speedtest
import threading
import time  # Importieren


class SpeedtestTab(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.grid_columnconfigure(0, weight=1)
        # Zusätzliche Reihe für Progressbar, also Ergebnisse bis row=2, Status row=3, Progress row=4
        # Textbox gibt es hier nicht, also keine rowconfigure nötig für Ausdehnung

        self.st_thread = None  # Thread speichern
        self.st = None  # Speedtest Objekt speichern (falls Abbruch nötig wäre)
        self.erg_font = ("Calibri", 30,"bold")  # Schriftart für Ergebnisse

        # --- Widgets ---
        self.label_title = ctk.CTkLabel(self, text="Speedtest")
        self.label_title.grid(row=0, column=0, columnspan=2, padx=10, pady=10)

        self.button_start = ctk.CTkButton(
            self, text="Speedtest starten", command=self.start_speedtest_thread)
        self.button_start.grid(row=1, column=0, columnspan=2, padx=10, pady=10)

        # Frame für Ergebnisse
        self.results_frame = ctk.CTkFrame(self)
        self.results_frame.grid(
            row=2, column=0, columnspan=2, padx=10, pady=10, sticky="ew")
        self.results_frame.grid_columnconfigure(1, weight=1)

        # Labels für die Ergebniswerte initialisieren
        self.label_ping = ctk.CTkLabel(self.results_frame, text="Ping:")
        self.label_ping.grid(row=0, column=0, padx=10, pady=5, sticky="w")
        self.value_ping = ctk.CTkLabel(self.results_frame, pady=5,text="",font=self.erg_font)
        self.value_ping.grid(row=0, column=1, padx=10, pady=5, sticky="w")

        self.label_download = ctk.CTkLabel(
            self.results_frame, text="Download:")
        self.label_download.grid(row=1, column=0, padx=10, pady=5, sticky="w")
        self.value_download = ctk.CTkLabel(self.results_frame,text="",font=self.erg_font)
        self.value_download.grid(row=1, column=1, padx=10, pady=5, sticky="w")

        self.label_upload = ctk.CTkLabel(self.results_frame, text="Upload:")
        self.label_upload.grid(row=2, column=0, padx=10, pady=5, sticky="w")
        self.value_upload = ctk.CTkLabel(self.results_frame,text="",font=self.erg_font)
        self.value_upload.grid(row=2, column=1, padx=10, pady=5, sticky="w")

        # Status Label
        self.status_label = ctk.CTkLabel(self, text="Bereit.")
        self.status_label.grid(
            row=3, column=0, columnspan=2, padx=10, pady=5, sticky="w")

        # Progress Bar (indeterminate)
        self.progress_bar = ctk.CTkProgressBar(
            self, orientation="horizontal", mode="indeterminate")
        # self.progress_bar wird bei Bedarf in row=4 platziert

    def start_speedtest_thread(self):
        # Reset UI elements before starting
        self.button_start.configure(state="disabled", text="Läuft...")
        self.status_label.configure(text="Initialisiere Speedtest...")
        self.value_ping.configure(text="- ms")
        self.value_download.configure(text="- Mbit/s")
        self.value_upload.configure(text="- Mbit/s")

        # Zeige und starte Progressbar
        self.progress_bar.grid(
            row=4, column=0, columnspan=2, padx=10, pady=5, sticky="ew")
        self.progress_bar.start()

        # Starte den Test im Hintergrund Thread
        self.st_thread = threading.Thread(
            target=self.run_speedtest_sequential_update, daemon=True)
        self.st_thread.start()

    def run_speedtest_sequential_update(self):
        """Führt den Speedtest durch und aktualisiert die GUI nach jeder Phase."""
        ping_val, download_val, upload_val = "-", "-", "-"
        error_message = None

        try:
            # --- Phase 1: Serverauswahl und Ping ---
            self.after(0, self._update_status, "Suche besten Server...")
            self.st = speedtest.Speedtest(secure=True)  # Kann eine Weile dauern
            # Optional: Serverliste holen (dauert länger, nicht unbedingt nötig für best_server)
            # self.st.get_servers()
            self.st.get_best_server()  # Wählt Server und misst Ping (blockierend)

            ping_val = f"{self.st.results.ping:.2f}"
            # Update Ping sofort nach der Messung
            self.after(0, self._update_specific_result,
                       "ping", f"{ping_val} ms")
            self.after(0, self._update_status,
                       "Ping gemessen. Messe Download...")

            # --- Phase 2: Download ---
            download_speed_bps = self.st.download()  # Blockierend
            download_val = f"{download_speed_bps / 1_000_000:.2f}"
            # Update Download sofort nach der Messung
            self.after(0, self._update_specific_result,
                       "download", f"{download_val} Mbit/s")
            self.after(0, self._update_status,
                       "Download gemessen. Messe Upload...")

            # --- Phase 3: Upload ---
            upload_speed_bps = self.st.upload()  # Blockierend
            upload_val = f"{upload_speed_bps / 1_000_000:.2f}"
            # Update Upload sofort nach der Messung
            self.after(0, self._update_specific_result,
                       "upload", f"{upload_val} Mbit/s")
            self.after(0, self._update_status, "Speedtest abgeschlossen.")

        except speedtest.SpeedtestException as e:
            # Begrenze Fehlermeldungslänge evtl.
            error_message = f"Speedtest Fehler: {str(e)[:100]}"
            print(f"Speedtest Fehler: {e}")  # Vollständige Meldung in Konsole
            self.after(0, self._update_status, error_message)
        except Exception as e:
            error_message = f"Allgemeiner Fehler: {str(e)[:100]}"
            print(f"Allgemeiner Fehler im Speedtest: {e}")
            self.after(0, self._update_status, error_message)
        finally:
            # Finalisiere UI immer, egal ob Erfolg oder Fehler
            self.after(0, self.finalize_speedtest)

    def _update_specific_result(self, result_type, value):
        """Aktualisiert das Label für ein spezifisches Ergebnis (Ping, Down, Up)."""
        try:
            if result_type == "ping" and self.value_ping.winfo_exists():
                self.value_ping.configure(text=value)
            elif result_type == "download" and self.value_download.winfo_exists():
                self.value_download.configure(text=value)
            elif result_type == "upload" and self.value_upload.winfo_exists():
                self.value_upload.configure(text=value)
        except Exception as e:
            print(
                f"Fehler beim Aktualisieren des Ergebnis-Labels ({result_type}): {e}")

    def _update_status(self, text):
        """Aktualisiert das Status-Label."""
        try:
            if self.status_label.winfo_exists():
                self.status_label.configure(text=text)
        except Exception as e:
            print(f"Fehler beim Aktualisieren des Status-Labels: {e}")

    def finalize_speedtest(self):
        """Setzt die UI nach Abschluss des Tests zurück."""
        # Prüfe ob Widgets noch existieren, falls Fenster geschlossen wurde
        if self.button_start.winfo_exists():
            self.button_start.configure(
                state="normal", text="Speedtest starten")
        if self.progress_bar.winfo_exists():
            self.progress_bar.stop()
            self.progress_bar.grid_forget()  # Verstecke die Progressbar wieder
        # Status Label wurde schon in run_speedtest_sequential_update gesetzt

        self.st_thread = None
        self.st = None  # Referenz löschen

    # Optional: Implementiere destroy, falls man den Test abbrechen können möchte
    # (Obwohl Speedtest abbrechen schwierig ist, könnte man den Thread "verlassen")
    # def destroy(self):
    #     # Hier könnte man versuchen, den Thread zu signalisieren, aber da die
    #     # speedtest-Methoden blockieren, ist ein sauberer Abbruch schwer.
    #     print("SpeedtestTab wird zerstört.")
    #     super().destroy()
