# tabs/public_ip_tab.py

import customtkinter as ctk
import requests
import threading
import re # Importiere Regex für IP-Validierung

class PublicIPTab(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        # Konfiguriere Spalten: Spalte 1 soll sich ausdehnen
        self.grid_columnconfigure(1, weight=1)

        # Größere Schriftart für die IP-Adressen definieren
        self.ip_font = ("Calibri", 40, "bold") # Oder eine andere Schriftart/Größe

        # --- Widgets ---
        self.label_title = ctk.CTkLabel(self, text="Öffentliche IP-Adressen", font=("Calibri", 16))
        # Erstreckt sich über 2 Spalten
        self.label_title.grid(row=0, column=0, columnspan=2, padx=10, pady=(10, 15))

        self.button_fetch = ctk.CTkButton(self, text="IP-Adressen abrufen", command=self.start_fetch_ip_thread)
        # Erstreckt sich über 2 Spalten
        self.button_fetch.grid(row=1, column=0, columnspan=2, padx=10, pady=10)

        # --- IPv4 Anzeige ---
        self.label_ipv4_title = ctk.CTkLabel(self, text="IPv4-Adresse:",font=("Calibri", 16))
        self.label_ipv4_title.grid(row=2, column=0, padx=(10, 5), pady=5, sticky="w")
        # Verwende die größere Schriftart und Hintergrund
        self.label_ipv4_result = ctk.CTkLabel(self, text="...", font=self.ip_font, corner_radius=5)
        self.label_ipv4_result.grid(row=2, column=1, padx=(0, 10), pady=5, sticky="ew")
        # Binde Doppelklick zum Kopieren, übergibt das Label-Widget selbst
        self.label_ipv4_result.bind("<Double-Button-1>", lambda e: self.copy_ip_to_clipboard(label_widget=self.label_ipv4_result))

        # --- IPv6 Anzeige ---
        self.label_ipv6_title = ctk.CTkLabel(self, text="IPv6-Adresse:",font=("Calibri", 16))
        self.label_ipv6_title.grid(row=3, column=0, padx=(10, 5), pady=5, sticky="w")
        # Verwende die größere Schriftart und Hintergrund
        self.label_ipv6_result = ctk.CTkLabel(self, text="...", font=self.ip_font,  corner_radius=5)
        self.label_ipv6_result.grid(row=3, column=1, padx=(0, 10), pady=5, sticky="ew")
        # Binde Doppelklick zum Kopieren
        self.label_ipv6_result.bind("<Double-Button-1>", lambda e: self.copy_ip_to_clipboard(label_widget=self.label_ipv6_result))

        # --- Status Label ---
        self.status_label = ctk.CTkLabel(self, text="", font=("Calibri", 12))
        # Erstreckt sich über 2 Spalten
        self.status_label.grid(row=4, column=0, columnspan=2, padx=10, pady=30, sticky="sw")

        # Optional: Automatisch beim Start laden
        self.after(100, self.start_fetch_ip_thread) # Kleine Verzögerung nach dem Start

    def start_fetch_ip_thread(self):
        """Startet den Abrufprozess im Hintergrund."""
        self.button_fetch.configure(state="disabled", text="Abrufen...")
        self.status_label.configure(text="Rufe IPs ab...")
        # Beide Labels zurücksetzen
        self.label_ipv4_result.configure(text="Suche...")
        self.label_ipv6_result.configure(text="Suche...")

        thread = threading.Thread(target=self.fetch_public_ips_separately, daemon=True)
        thread.start()

    def _fetch_single_ip(self, url, ip_type_check):
        """Hilfsfunktion zum Abrufen einer einzelnen IP von einer URL."""
        headers = {'User-Agent': 'Mozilla/5.0 NetworkToolsApp/1.0'}
        timeout_seconds = 4 # Etwas kürzerer Timeout pro Anfrage
        try:
            response = requests.get(url, timeout=timeout_seconds, headers=headers)
            response.raise_for_status()
            # ipify gibt JSON zurück, andere reinen Text
            if "ipify" in url and "json" in url:
                 ip_address = response.json().get("ip")
            else:
                 ip_address = response.text.strip()

            if ip_address and ip_type_check(ip_address):
                return ip_address
        except requests.exceptions.RequestException as e:
            print(f"Fehler beim Abrufen von {url}: {e}") # Log für Debugging
        return None # Kein Erfolg

    def fetch_public_ips_separately(self):
        """Versucht, IPv4 und IPv6 separat über dedizierte Dienste abzurufen."""
        results = {'ipv4': 'N/A', 'ipv6': 'N/A'} # Standard: Nicht verfügbar

        # --- IPv4 Abruf ---
        ipv4 = self._fetch_single_ip("https://api.ipify.org?format=json", self.is_valid_ipv4)
        if not ipv4: # Fallback
             ipv4 = self._fetch_single_ip("https://ipv4.icanhazip.com", self.is_valid_ipv4)
        if ipv4:
            results['ipv4'] = ipv4
        else:
             results['ipv4'] = "-----" # Wenn beide fehlschlagen

        # --- IPv6 Abruf ---
        ipv6 = self._fetch_single_ip("https://api6.ipify.org?format=json", self.is_valid_ipv6)
        if not ipv6: # Fallback
            ipv6 = self._fetch_single_ip("https://ipv6.icanhazip.com", self.is_valid_ipv6)
        if ipv6:
             results['ipv6'] = ipv6
        else:
             # Es ist normal, keine IPv6 zu haben, daher eher "N/A" als "Fehler"
             results['ipv6'] = "-----"


        # Ergebnisse im Hauptthread anzeigen
        self.after(0, self.update_ip_display, results)
        self.after(0, self.finalize_fetch)

    # --- IP Validierungsfunktionen ---
    def is_valid_ipv4(self, ip_str):
        """Prüft, ob der String eine gültige IPv4-Adresse ist."""
        if not ip_str or not isinstance(ip_str, str): return False
        pattern = re.compile(r"^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$")
        return pattern.match(ip_str) is not None

    def is_valid_ipv6(self, ip_str):
        """Prüft, ob der String eine gültige IPv6-Adresse ist (vereinfachte Prüfung)."""
        if not ip_str or not isinstance(ip_str, str): return False
        # Diese Regex ist nicht perfekt für alle IPv6-Varianten (z.B. ::1), aber gut genug für typische öffentliche IPs
        pattern = re.compile(r"^(?:[A-F0-9]{1,4}:){7}[A-F0-9]{1,4}$", re.IGNORECASE) # Volle Länge
        pattern_compressed = re.compile(r"^(?:[A-F0-9]{1,4}:){1,7}:(?:[A-F0-9]{1,4}:){1,7}", re.IGNORECASE) # Komprimiert (vereinfacht)
        # TODO: Bessere IPv6 Regex / Validierung bei Bedarf
        return pattern.match(ip_str) is not None or "::" in ip_str # Einfacher Check auf Komprimierung

    def update_ip_display(self, ip_results):
        """Aktualisiert die IPv4 und IPv6 Labels."""
        ipv4_text = ip_results.get('ipv4', 'Fehler')
        ipv6_text = ip_results.get('ipv6', 'N/A')

        self.label_ipv4_result.configure(text=ipv4_text)
        self.label_ipv6_result.configure(text=ipv6_text)

    def finalize_fetch(self):
        """Setzt den Button-Status zurück und aktualisiert die Statusmeldung."""
        self.button_fetch.configure(state="normal", text="IP-Adressen abrufen")
        # Prüfe, ob mindestens eine IP erfolgreich abgerufen wurde
        ipv4_ok = self.label_ipv4_result.cget("text") not in ["...", "N/A", "Fehler", "Suche..."]
        ipv6_ok = self.label_ipv6_result.cget("text") not in ["...", "N/A", "Fehler", "Suche..."]

        if ipv4_ok or ipv6_ok:
            self.status_label.configure(text="Abruf abgeschlossen.")
        else:
            self.status_label.configure(text="Konnte keine IPs abrufen.")

    def copy_ip_to_clipboard(self, event=None, label_widget=None):
        """Kopiert den Text des übergebenen Labels in die Zwischenablage."""
        if label_widget:
            ip_text = label_widget.cget("text")
            # Kopiere nur, wenn es eine gültige IP zu sein scheint
            valid_to_copy = ip_text and ip_text not in ["...", "N/A", "Fehler", "Suche..."]

            if valid_to_copy:
                try:
                    self.clipboard_clear()
                    self.clipboard_append(ip_text)
                    self.update() # Notwendig, damit die Zwischenablage sofort aktualisiert wird
                    self.status_label.configure(text=f"'{ip_text}' kopiert!")
                    # Optional: Kurze visuelle Bestätigung am Label selbst
                    original_color = label_widget.cget("fg_color")
                    label_widget.configure(fg_color="green")
                    self.after(500, lambda: label_widget.configure(fg_color=original_color))
                except Exception as e:
                    print(f"Fehler beim Kopieren in die Zwischenablage: {e}")
                    self.status_label.configure(text="Fehler beim Kopieren.")
            else:
                self.status_label.configure(text="Nichts zum Kopieren ausgewählt.")
        else:
             self.status_label.configure(text="Kopierfehler (intern).")