# tabs/ip_settings_tab.py
import customtkinter as ctk
import platform
import json
import os
from tkinter import messagebox
import threading

# Importiere die Hilfsfunktionen
from utils.admin_check import is_admin

# Importiere Windows-spezifische Funktionen nur, wenn auf Windows
if platform.system().lower() == "windows":
    from utils.network_utils_windows import (
        get_active_adapters_windows,
        get_ip_config_windows,
        set_dhcp_windows,
        set_static_ip_windows,
        set_static_dns_windows
    )
else:
    # Platzhalter oder Fehlermeldungen für andere Systeme
    def get_active_adapters_windows(): return ["Nicht Windows"]
    def get_ip_config_windows(adapter_name): return {"ip": "N/A", "subnet": "N/A", "gateway": "N/A", "dns": [], "dhcp_enabled": False}
    def set_dhcp_windows(adapter_name): return False, "Funktion nur für Windows verfügbar."
    def set_static_ip_windows(adapter_name, ip, subnet, gateway): return False, "Funktion nur für Windows verfügbar."
    def set_static_dns_windows(adapter_name, dns1, dns2=None): return False, "Funktion nur für Windows verfügbar."


PROFILES_FILE = "ip_profiles.json"
LAST_ADAPTER_FILE = "last_adapter.json"  # Neue Konstante für letzten Adapter

class IPSettingsTab(ctk.CTkFrame):
    def __init__(self, master, is_admin=False, **kwargs):
        super().__init__(master, **kwargs)
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        self.is_admin = is_admin
        self.selected_adapter = None
        self.profiles = self._load_profiles_from_file()

        # --- Admin Warnung ---
        if not self.is_admin:
            warning_label = ctk.CTkLabel(self, text="WARNUNG: Eingeschränkter Modus! Netzwerkeinstellungen können nicht geändert werden.",
                                         text_color="orange", font=("", 12, "bold"))
            warning_label.grid(row=0, column=0, columnspan=2, padx=10, pady=5, sticky="ew")
            start_row = 1
        else:
            start_row = 0

        # --- Adapter Auswahl ---
        adapter_frame = ctk.CTkFrame(self)
        adapter_frame.grid(row=start_row, column=0, columnspan=2, padx=10, pady=5, sticky="ew")
        adapter_frame.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(adapter_frame, text="Netzwerkadapter:").grid(row=0, column=0, padx=(10,5), pady=5, sticky="w")
        self.combo_adapters = ctk.CTkComboBox(adapter_frame, values=[""], command=self._on_adapter_select, state="readonly")
        self.combo_adapters.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        self.btn_refresh_adapters = ctk.CTkButton(adapter_frame, text="Aktualisieren", width=100, command=self._load_adapters)
        self.btn_refresh_adapters.grid(row=0, column=2, padx=(5,10), pady=5)

        # --- Aktuelle Konfiguration (Linke Spalte) ---
        config_frame = ctk.CTkFrame(self,width=200)
        config_frame.grid(row=start_row + 1, column=0, padx=10, pady=5, sticky="nsew")
        config_frame.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(config_frame, text="Aktuelle Konfiguration:", font=("", 12, "bold")).grid(row=0, column=0, columnspan=2, pady=(5,10))

        ctk.CTkLabel(config_frame, text="DHCP Aktiv:").grid(row=1, column=0, padx=5, pady=2, sticky="w")
        self.lbl_current_dhcp = ctk.CTkLabel(config_frame, text="-")
        self.lbl_current_dhcp.grid(row=1, column=1, padx=5, pady=2, sticky="w")

        ctk.CTkLabel(config_frame, text="IP-Adresse:").grid(row=2, column=0, padx=5, pady=2, sticky="w")
        self.lbl_current_ip = ctk.CTkLabel(config_frame, text="-")
        self.lbl_current_ip.grid(row=2, column=1, padx=5, pady=2, sticky="w")

        ctk.CTkLabel(config_frame, text="Subnetzmaske:").grid(row=3, column=0, padx=5, pady=2, sticky="w")
        self.lbl_current_subnet = ctk.CTkLabel(config_frame, text="-")
        self.lbl_current_subnet.grid(row=3, column=1, padx=5, pady=2, sticky="w")

        ctk.CTkLabel(config_frame, text="Gateway:").grid(row=4, column=0, padx=5, pady=2, sticky="w")
        self.lbl_current_gateway = ctk.CTkLabel(config_frame, text="-")
        self.lbl_current_gateway.grid(row=4, column=1, padx=5, pady=2, sticky="w")

        ctk.CTkLabel(config_frame, text="DNS-Server:").grid(row=5, column=0, padx=5, pady=2, sticky="w")
        self.lbl_current_dns = ctk.CTkLabel(config_frame, text="-")
        self.lbl_current_dns.grid(row=5, column=1, padx=5, pady=2, sticky="w")

        self.btn_refresh_config = ctk.CTkButton(config_frame, text="Akt. Konfig. neu laden", command=self._display_config)
        self.btn_refresh_config.grid(row=6, column=0, columnspan=2, pady=10)

        # --- Einstellungen ändern (Rechte Spalte) ---
        settings_frame = ctk.CTkFrame(self,width=350)
        settings_frame.grid(row=start_row + 1, column=1, padx=10, pady=5, sticky="nsew")
        settings_frame.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(settings_frame, text="Einstellungen ändern:", font=("", 12, "bold")).grid(row=0, column=0, columnspan=2, pady=(5,10))

        # DHCP / Statisch Radio Buttons
        self.radio_var = ctk.StringVar(value="dhcp")
        self.radio_dhcp = ctk.CTkRadioButton(settings_frame, text="DHCP beziehen", variable=self.radio_var, value="dhcp", command=self._toggle_static_fields)
        self.radio_dhcp.grid(row=1, column=0, padx=10, pady=5, sticky="w")
        self.radio_static = ctk.CTkRadioButton(settings_frame, text="Statische IP verwenden", variable=self.radio_var, value="static", command=self._toggle_static_fields)
        self.radio_static.grid(row=1, column=1, padx=10, pady=5, sticky="w")

        # Frame für statische Einstellungen
        self.frame_static_settings = ctk.CTkFrame(settings_frame, fg_color="transparent")
        self.frame_static_settings.grid(row=2, column=0, columnspan=2, padx=5, pady=5, sticky="ew")
        self.frame_static_settings.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(self.frame_static_settings, text="IP-Adresse:").grid(row=0, column=0, padx=5, pady=2, sticky="w")
        self.entry_ip = ctk.CTkEntry(self.frame_static_settings)
        self.entry_ip.grid(row=0, column=1, padx=5, pady=2, sticky="ew")

        ctk.CTkLabel(self.frame_static_settings, text="Subnetzmaske:").grid(row=1, column=0, padx=5, pady=2, sticky="w")
        self.entry_subnet = ctk.CTkEntry(self.frame_static_settings)
        self.entry_subnet.grid(row=1, column=1, padx=5, pady=2, sticky="ew")

        ctk.CTkLabel(self.frame_static_settings, text="Gateway:").grid(row=2, column=0, padx=5, pady=2, sticky="w")
        self.entry_gateway = ctk.CTkEntry(self.frame_static_settings)
        self.entry_gateway.grid(row=2, column=1, padx=5, pady=2, sticky="ew")

        ctk.CTkLabel(self.frame_static_settings, text="DNS 1:").grid(row=3, column=0, padx=5, pady=2, sticky="w")
        self.entry_dns1 = ctk.CTkEntry(self.frame_static_settings)
        self.entry_dns1.grid(row=3, column=1, padx=5, pady=2, sticky="ew")

        ctk.CTkLabel(self.frame_static_settings, text="DNS 2 (opt.):").grid(row=4, column=0, padx=5, pady=2, sticky="w")
        self.entry_dns2 = ctk.CTkEntry(self.frame_static_settings)
        self.entry_dns2.grid(row=4, column=1, padx=5, pady=2, sticky="ew")

        # Apply Button
        self.btn_apply = ctk.CTkButton(settings_frame, text="Einstellungen Anwenden", command=self._apply_settings, state="disabled" if not self.is_admin else "normal")
        self.btn_apply.grid(row=3, column=0, columnspan=2, pady=15)

        # --- Profile (Unten über beide Spalten) ---
        profile_outer_frame = ctk.CTkFrame(self)
        profile_outer_frame.grid(row=start_row + 2, column=0, columnspan=2, padx=10, pady=10, sticky="ew")
        profile_outer_frame.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(profile_outer_frame, text="Profile:", font=("", 12, "bold")).grid(row=0, column=0, columnspan=3, pady=(5,10))

        # Profil Auswahl und Laden
        ctk.CTkLabel(profile_outer_frame, text="Profil laden:").grid(row=1, column=0, padx=(10,5), pady=5, sticky="w")
        self.combo_profiles = ctk.CTkComboBox(profile_outer_frame, values=[""], command=None, state="readonly")
        self.combo_profiles.grid(row=1, column=1, padx=5, pady=5, sticky="ew")
        self.btn_load_profile = ctk.CTkButton(profile_outer_frame, text="Laden", width=70, command=self._load_selected_profile_to_ui)
        self.btn_load_profile.grid(row=1, column=2, padx=5, pady=5)
        self.btn_delete_profile = ctk.CTkButton(profile_outer_frame, text="Löschen", width=70, fg_color="red", hover_color="darkred", command=self._delete_selected_profile)
        self.btn_delete_profile.grid(row=1, column=3, padx=(0,10), pady=5)

        # Profil Speichern
        ctk.CTkLabel(profile_outer_frame, text="Neues Profil:").grid(row=2, column=0, padx=(10,5), pady=5, sticky="w")
        self.entry_profile_name = ctk.CTkEntry(profile_outer_frame, placeholder_text="Profilname eingeben...")
        self.entry_profile_name.grid(row=2, column=1, padx=5, pady=5, sticky="ew")
        self.btn_save_profile = ctk.CTkButton(profile_outer_frame, text="Akt. Einstellungen als Profil speichern", width=150, command=self._save_current_settings_as_profile)
        self.btn_save_profile.grid(row=2, column=2, columnspan=2, padx=(5,10), pady=5)

        # --- Status Bar ---
        self.status_label = ctk.CTkLabel(self, text="Bereit.")
        self.status_label.grid(row=start_row + 3, column=0, columnspan=2, padx=10, pady=(5, 5), sticky="w")

        # --- Initialisierung ---
        self._load_adapters()
        self._toggle_static_fields()
        self._update_profile_list()
        
        # Letzten Adapter laden
        last_adapter = self._load_last_adapter()
        adapters = self.combo_adapters.cget("values")

        if last_adapter:
            self._display_config()

        
        if last_adapter and last_adapter in adapters:
            self.combo_adapters.set(last_adapter)
            self._on_adapter_select(last_adapter)
        elif adapters:
            first_adapter = adapters[0]
            self.combo_adapters.set(first_adapter)
            self._on_adapter_select(first_adapter)

    # +++ Neue Methoden für letzten Adapter +++
    def _save_last_adapter(self, adapter_name):
        """Speichert den zuletzt ausgewählten Adapter."""
        try:
            with open(LAST_ADAPTER_FILE, 'w') as f:
                json.dump({"last_adapter": adapter_name}, f)
        except Exception as e:
            print(f"Fehler beim Speichern: {str(e)}")

    def _load_last_adapter(self):
        """Lädt den zuletzt ausgewählten Adapter."""
        try:
            if os.path.exists(LAST_ADAPTER_FILE):
                with open(LAST_ADAPTER_FILE, 'r') as f:
                    data = json.load(f)
                    return data.get("last_adapter")
        except Exception as e:
            print(f"Fehler beim Laden: {str(e)}")
        return None

    # +++ Modifizierte Methoden +++
    def _load_adapters(self):
        """Lädt Netzwerkadapter mit letztem Adapter-Check."""
        self.status_label.configure(text="Lade Adapter...")
        adapters = get_active_adapters_windows() if platform.system().lower() == "windows" else ["Nicht-Windows-System"]
        
        # Prüfe auf veralteten gespeicherten Adapter
        last_adapter = self._load_last_adapter()
        if last_adapter and last_adapter not in adapters:
            self._save_last_adapter("")

        if not adapters:
            adapters = ["Keine aktiven Adapter gefunden"]
            self.combo_adapters.configure(state="disabled")
        else:
            self.combo_adapters.configure(state="readonly")

        self.combo_adapters.configure(values=adapters)
        self.combo_adapters.set(adapters[0] if adapters else "")
        self.selected_adapter = adapters[0] if adapters else None
        self._display_config()
        self.status_label.configure(text="Adapter geladen.")

    def _on_adapter_select(self, selected_adapter_name):
        """Verarbeitet Adapterauswahl und speichert sie."""
        self.selected_adapter = selected_adapter_name
        self._save_last_adapter(selected_adapter_name)  # Neuer Speichervorgang
        print(f"Adapter ausgewählt: {self.selected_adapter}")
        self._display_config()

    # --- Originalmethoden (unverändert) ---
    def _display_config(self):
        if not self.selected_adapter or self.selected_adapter.startswith("Keine"):
            self._clear_current_config_labels()
            self.status_label.configure(text="Kein Adapter ausgewählt.")
            return

        self.status_label.configure(text=f"Lade Konfiguration für {self.selected_adapter}...")
        self.update()

        thread = threading.Thread(target=self._fetch_and_display_config_thread, daemon=True)
        thread.start()

    def _fetch_and_display_config_thread(self):
        config = get_ip_config_windows(self.selected_adapter)
        self.after(0, self._update_config_labels, config)

    def _update_config_labels(self, config):
        self.lbl_current_dhcp.configure(text="Ja" if config.get("dhcp_enabled") else "Nein")
        self.lbl_current_ip.configure(text=config.get("ip", "-"))
        self.lbl_current_subnet.configure(text=config.get("subnet", "-"))
        self.lbl_current_gateway.configure(text=config.get("gateway", "-"))
        self.lbl_current_dns.configure(text=", ".join(config.get("dns", [])) or "-")
        self.status_label.configure(text=f"Konfiguration für {self.selected_adapter} angezeigt.")

    def _clear_current_config_labels(self):
        self.lbl_current_dhcp.configure(text="-")
        self.lbl_current_ip.configure(text="-")
        self.lbl_current_subnet.configure(text="-")
        self.lbl_current_gateway.configure(text="-")
        self.lbl_current_dns.configure(text="-")

    def _toggle_static_fields(self):
        if self.radio_var.get() == "static":
            for widget in self.frame_static_settings.winfo_children():
                if isinstance(widget, ctk.CTkEntry):
                    widget.configure(state="normal")
        else:
            for widget in self.frame_static_settings.winfo_children():
                if isinstance(widget, ctk.CTkEntry):
                    widget.configure(state="disabled")

    def _apply_settings(self):
        if not self.is_admin:
            messagebox.showerror("Fehler", "Keine Admin-Rechte!")
            return

        if not self.selected_adapter or self.selected_adapter.startswith("Keine"):
            messagebox.showerror("Fehler", "Kein Adapter ausgewählt!")
            return

        mode = self.radio_var.get()
        adapter = self.selected_adapter

        confirm_msg = f"Einstellungen für '{adapter}' ändern?\nModus: {mode.upper()}"
        if mode == 'static':
             ip = self.entry_ip.get()
             subnet = self.entry_subnet.get()
             gw = self.entry_gateway.get()
             dns1 = self.entry_dns1.get()
             dns2 = self.entry_dns2.get()
             if not ip or not subnet or not dns1:
                 messagebox.showerror("Fehler", "IP, Subnetz und DNS1 benötigt!")
                 return
             confirm_msg += f"\nIP: {ip}\nSubnetz: {subnet}\nGateway: {gw or '-'}\nDNS1: {dns1}\nDNS2: {dns2 or '-'}"

        if not messagebox.askyesno("Bestätigung", confirm_msg + "\n\nNetzwerk kann unterbrochen werden!"):
            return

        self.status_label.configure(text=f"Wende Einstellungen an...")
        self.btn_apply.configure(state="disabled")
        self.update()

        thread = threading.Thread(target=self._apply_settings_thread, args=(adapter, mode), daemon=True)
        thread.start()

    def _apply_settings_thread(self, adapter, mode):
        success = False
        error_msg = ""

        if mode == "dhcp":
            success, error_msg = set_dhcp_windows(adapter)
        elif mode == "static":
            ip = self.entry_ip.get()
            subnet = self.entry_subnet.get()
            gateway = self.entry_gateway.get() or None
            dns1 = self.entry_dns1.get()
            dns2 = self.entry_dns2.get() or None

            success_ip, error_ip = set_static_ip_windows(adapter, ip, subnet, gateway)
            if success_ip:
                 success_dns, error_dns = set_static_dns_windows(adapter, dns1, dns2)
                 success = success_dns
                 error_msg = error_dns
            else:
                 success = False
                 error_msg = error_ip

        self.after(0, self._finalize_apply, success, error_msg)

    def _finalize_apply(self, success, error_msg):
        if success:
            self.status_label.configure(text="Einstellungen erfolgreich!")
            messagebox.showinfo("Erfolg", "Änderungen übernommen.")
            self._display_config()
        else:
            self.status_label.configure(text=f"Fehler: {error_msg[:100]}")
            messagebox.showerror("Fehler", f"Fehler:\n\n{error_msg}")

        if self.btn_apply.winfo_exists():
            self.btn_apply.configure(state="normal" if self.is_admin else "disabled")

    def _load_profiles_from_file(self):
        if os.path.exists(PROFILES_FILE):
            try:
                with open(PROFILES_FILE, 'r') as f:
                    return json.load(f)
            except Exception as e:
                print(f"Ladefehler: {str(e)}")
                messagebox.showerror("Fehler", f"Profil-Dateifehler:\n{str(e)}")
                return {}
        return {}

    def _save_profiles_to_file(self):
        try:
            with open(PROFILES_FILE, 'w') as f:
                json.dump(self.profiles, f, indent=4)
            return True
        except Exception as e:
            print(f"Speicherfehler: {str(e)}")
            messagebox.showerror("Fehler", f"Speichern fehlgeschlagen:\n{str(e)}")
            return False

    def _update_profile_list(self):
        profile_names = list(self.profiles.keys())
        if not profile_names:
            profile_names = ["Keine Profile"]
            self.combo_profiles.configure(state="disabled")
            self.btn_load_profile.configure(state="disabled")
            self.btn_delete_profile.configure(state="disabled")
        else:
            self.combo_profiles.configure(state="readonly")
            self.btn_load_profile.configure(state="normal")
            self.btn_delete_profile.configure(state="normal")

        self.combo_profiles.configure(values=profile_names)
        self.combo_profiles.set(profile_names[0] if profile_names else "")

    def _load_selected_profile_to_ui(self):
        profile_name = self.combo_profiles.get()
        if not profile_name or profile_name == "Keine Profile":
            messagebox.showwarning("Info", "Kein Profil ausgewählt!")
            return

        if profile_name not in self.profiles:
             messagebox.showerror("Fehler", "Profil nicht gefunden!")
             self.profiles = self._load_profiles_from_file()
             self._update_profile_list()
             return

        profile_data = self.profiles[profile_name]

        saved_adapter = profile_data.get("adapter")
        if saved_adapter and self.selected_adapter and saved_adapter != self.selected_adapter:
            messagebox.showinfo("Info", f"Profil für '{saved_adapter}' gespeichert. Aktuell: '{self.selected_adapter}'")

        is_dhcp = profile_data.get("dhcp", False)
        if is_dhcp:
            self.radio_var.set("dhcp")
            self.entry_ip.delete(0, "end")
            self.entry_subnet.delete(0, "end")
            self.entry_gateway.delete(0, "end")
            self.entry_dns1.delete(0, "end")
            self.entry_dns2.delete(0, "end")
        else:
            self.radio_var.set("static")
            self.entry_ip.delete(0, "end")
            self.entry_ip.insert(0, profile_data.get("ip", ""))
            self.entry_subnet.delete(0, "end")
            self.entry_subnet.insert(0, profile_data.get("subnet", ""))
            self.entry_gateway.delete(0, "end")
            self.entry_gateway.insert(0, profile_data.get("gateway", ""))
            self.entry_dns1.delete(0, "end")
            self.entry_dns1.insert(0, profile_data.get("dns1", ""))
            self.entry_dns2.delete(0, "end")
            self.entry_dns2.insert(0, profile_data.get("dns2", ""))

        self._toggle_static_fields()
        self.status_label.configure(text=f"Profil '{profile_name}' geladen.")

    def _save_current_settings_as_profile(self):
        profile_name = self.entry_profile_name.get().strip()
        if not profile_name:
            messagebox.showerror("Fehler", "Profilname benötigt!")
            return

        if profile_name in self.profiles:
            if not messagebox.askyesno("Bestätigen", f"Profil '{profile_name}' überschreiben?"):
                return

        new_profile = {"adapter": self.selected_adapter or "Unbekannt"}
        mode = self.radio_var.get()

        if mode == "dhcp":
            new_profile["dhcp"] = True
        else:
            new_profile["dhcp"] = False
            new_profile["ip"] = self.entry_ip.get()
            new_profile["subnet"] = self.entry_subnet.get()
            new_profile["gateway"] = self.entry_gateway.get()
            new_profile["dns1"] = self.entry_dns1.get()
            new_profile["dns2"] = self.entry_dns2.get()
            if not new_profile["ip"] or not new_profile["subnet"] or not new_profile["dns1"]:
                 messagebox.showerror("Fehler", "IP, Subnetz und DNS1 benötigt!")
                 return

        self.profiles[profile_name] = new_profile
        if self._save_profiles_to_file():
            self.status_label.configure(text=f"Profil '{profile_name}' gespeichert.")
            self.entry_profile_name.delete(0, "end")
            self._update_profile_list()
            self.combo_profiles.set(profile_name)
            messagebox.showinfo("Erfolg", f"Profil '{profile_name}' gespeichert!")
        else:
             self.status_label.configure(text="Speichern fehlgeschlagen.")

    def _delete_selected_profile(self):
        profile_name = self.combo_profiles.get()
        if not profile_name or profile_name == "Keine Profile":
            messagebox.showwarning("Info", "Kein Profil ausgewählt!")
            return

        if profile_name not in self.profiles:
             messagebox.showerror("Fehler", "Profil nicht gefunden!")
             self.profiles = self._load_profiles_from_file()
             self._update_profile_list()
             return

        if messagebox.askyesno("Löschen", f"Profil '{profile_name}' wirklich löschen?"):
            del self.profiles[profile_name]
            if self._save_profiles_to_file():
                self.status_label.configure(text=f"Profil '{profile_name}' gelöscht.")
                self._update_profile_list()
                messagebox.showinfo("Erfolg", "Profil gelöscht!")
            else:
                self.status_label.configure(text="Löschen fehlgeschlagen.")