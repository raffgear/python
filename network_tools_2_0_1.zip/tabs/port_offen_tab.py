import customtkinter as ctk
import socket
import threading
import time
import re
from tkinter import messagebox


class PortTesterTab(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)

        self.test_thread = None
        self.stop_event = threading.Event()
        self.result_labels = {}
        self.ports_to_test = []

        # Schriftart für Ergebnisse definieren
        self.result_font = ("Calibri", 20)  # Schriftart für Ergebnis-Labels
        # Schriftart für Titelzeilen
        self.header_font = ("Calibri", 18, "bold")

        # --- Layout Konfiguration ---
        self.grid_columnconfigure(0, weight=1)
        # Reihen: 0: Inputs, 1: Controls, 2: Results, 3: Status
        # Ergebnisbereich soll sich ausdehnen
        self.grid_rowconfigure(2, weight=1)

        # --- Reihe 0: Host und Port Eingabe (bleibt gleich) ---
        input_frame = ctk.CTkFrame(self, fg_color="transparent")
        input_frame.grid(row=0, column=0, padx=10, pady=(10, 5), sticky="ew")
        input_frame.grid_columnconfigure(1, weight=1)
        input_frame.grid_columnconfigure(3, weight=1)

        ctk.CTkLabel(input_frame, text="Ziel-Host/IP:").grid(row=0,
                                                             column=0, padx=(0, 5), pady=5, sticky="w")
        self.entry_host = ctk.CTkEntry(
            input_frame, placeholder_text="z.B. google.com")
        self.entry_host.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        ctk.CTkLabel(input_frame, text="TCP-Ports:").grid(row=0,
                                                          column=2, padx=(10, 5), pady=5, sticky="w")
        self.entry_ports = ctk.CTkEntry(
            input_frame, placeholder_text="z.B. 80 443")
        self.entry_ports.grid(
            row=0, column=3, padx=(0, 0), pady=5, sticky="ew")
        self.entry_ports.bind(
            "<KeyRelease>", self._update_checkboxes_from_entry)

        self.entry_host.insert(0, "fritz.box")

        # --- Reihe 1: Checkboxen und Buttons (bleibt gleich) ---
        controls_frame = ctk.CTkFrame(self, fg_color="transparent")
        controls_frame.grid(row=1, column=0, padx=10, pady=5, sticky="ew")
        controls_frame.grid_columnconfigure(1, weight=1)
        checkbox_frame = ctk.CTkFrame(controls_frame, fg_color="transparent")
        checkbox_frame.grid(row=0, column=0, sticky="w")
        ctk.CTkLabel(checkbox_frame, text="Presets:").pack(
            side="left", padx=(0, 10))
        self.check_var_80 = ctk.StringVar(value="off")
        self.check_80 = ctk.CTkCheckBox(checkbox_frame, text="80", variable=self.check_var_80,
                                        onvalue="80", offvalue="off", command=self._update_ports_from_checkboxes, width=50)
        self.check_80.pack(side="left", padx=5)
        self.check_var_443 = ctk.StringVar(value="off")
        self.check_443 = ctk.CTkCheckBox(checkbox_frame, text="443", variable=self.check_var_443,
                                         onvalue="443", offvalue="off", command=self._update_ports_from_checkboxes, width=50)
        self.check_443.pack(side="left", padx=5)
        self.check_var_8802 = ctk.StringVar(value="off")
        self.check_8802 = ctk.CTkCheckBox(checkbox_frame, text="8802", variable=self.check_var_8802,
                                          onvalue="8802", offvalue="off", command=self._update_ports_from_checkboxes, width=50)
        self.check_8802.pack(side="left", padx=5)
        button_frame = ctk.CTkFrame(controls_frame, fg_color="transparent")
        button_frame.grid(row=0, column=2, sticky="e")
        self.btn_start = ctk.CTkButton(
            button_frame, text="Start", width=80, command=self.start_testing)
        self.btn_start.pack(side="left", padx=5)
        self.btn_stop = ctk.CTkButton(button_frame, text="Stop", width=80,
                                      command=self.stop_testing, state="disabled", fg_color="red", hover_color="darkred")
        self.btn_stop.pack(side="left", padx=5)

        # --- Reihe 2: Ergebnisbereich (Scrollable Frame MIT Headern) ---
        # Außenrahmen für Header und Scrollbereich
        result_outer_frame = ctk.CTkFrame(self)
        result_outer_frame.grid(
            row=2, column=0, padx=10, pady=5, sticky="nsew")
        # Konfiguriere Spalten im Außenrahmen, passend zu den Spalten *innerhalb* des Scrollbereichs
        # Spalte für Port-Header (fixe Breite)
        result_outer_frame.grid_columnconfigure(0, weight=1)
        # Spalte für Status-Header (dehnt sich aus)
        result_outer_frame.grid_columnconfigure(1, weight=4)
        # Konfiguriere Reihen im Außenrahmen: Reihe 1 (Scrollbereich) dehnt sich aus
        result_outer_frame.grid_rowconfigure(1, weight=1)

        # Header Labels (in row 0 des Außenrahmens)
        header_port = ctk.CTkLabel(
            result_outer_frame, text="Port", font=self.header_font)
        # Gleiches Padding/Sticky wie Port-Nummern-Label innen, aber in row 0
        # Leicht erhöhtes rechtes Padding für den Port-Header
        header_port.grid(row=0, column=0, padx=(
            40, 10), pady=(5, 2), sticky="e")

        header_status = ctk.CTkLabel(
            result_outer_frame, text="Status", font=self.header_font)
        # Angepasstes Padding für den Status-Header
        header_status.grid(row=0, column=1, padx=(190, 20), pady=(
            5, 2), sticky="w")  # Erhöhtes linkes Padding

        # Scrollable Frame (in row 1 des Außenrahmens, spannt über beide Spalten)
        # Entferne label_text, da wir separate Header haben
        self.scrollable_frame = ctk.CTkScrollableFrame(result_outer_frame)
        self.scrollable_frame.grid(
            row=1, column=0, columnspan=2, sticky="nsew", pady=(0, 5))
        # Spaltenkonfiguration *innerhalb* des Scrollable Frames bleibt gleich
        self.scrollable_frame.grid_columnconfigure(0, weight=1)
        self.scrollable_frame.grid_columnconfigure(1, weight=4)

        # --- Reihe 3: Statusleiste unten (bleibt gleich) ---
        self.status_label = ctk.CTkLabel(self, text="Bereit.")
        self.status_label.grid(row=3, column=0, padx=10,
                               pady=(5, 10), sticky="w")

        # Initial Checkbox Status Sync
        self._update_checkboxes_from_entry()

    # --- Test Logik ---

    def start_testing(self):
        # ... (Validierung etc. bleibt gleich) ...
        host = self.entry_host.get().strip()
        self.ports_to_test = self._get_ports_from_entry()
        if not host:
            messagebox.showerror(
                "Fehler", "Bitte geben Sie einen Ziel-Host ein.")
            return
        if not self.ports_to_test:
            messagebox.showerror("Fehler", "Bitte geben Sie Ports an.")
            return
        if self.test_thread and self.test_thread.is_alive():
            messagebox.showwarning("Info", "Test läuft bereits.")
            return

        # Alte Ergebnisse löschen
        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()
        self.result_labels.clear()

        # Neue Ergebnis-Labels erstellen
        for i, port in enumerate(self.ports_to_test):
            # Port-Label (Spalte 0) - NUR die Nummer anzeigen
            # Verwende str(port) statt f"Port {port}:"
            port_label = ctk.CTkLabel(
                self.scrollable_frame, text=str(port), font=self.result_font)
            # Leicht erhöhtes rechtes Padding
            port_label.grid(row=i, column=0, padx=(5, 10), pady=2, sticky="e")

            # Status-Label (Spalte 1) - Padding links erhöht
            status_label = ctk.CTkLabel(
                self.scrollable_frame, text="Warte...", width=100, corner_radius=5, font=self.result_font)
            # Linkes Padding auf 20 erhöht
            status_label.grid(row=i, column=1, padx=(
                20, 5), pady=2, sticky="ew")
            self.result_labels[port] = status_label

        # ... (Rest von start_testing: Thread starten, UI anpassen) ...
        self.stop_event.clear()
        self.test_thread = threading.Thread(target=self._run_port_test_loop, args=(
            host, self.ports_to_test[:]), daemon=True)
        self.test_thread.start()
        self.btn_start.configure(state="disabled")
        self.btn_stop.configure(state="normal")
        self.entry_host.configure(state="disabled")
        self.entry_ports.configure(state="disabled")
        self.check_80.configure(state="disabled")
        self.check_443.configure(state="disabled")
        self.check_8802.configure(state="disabled")
        self.status_label.configure(text=f"Teste Ports auf {host} alle 5 Sekunden")

    def _get_ports_from_entry(self):
        port_string = self.entry_ports.get().strip()
        ports = set()
        if not port_string:
            return []
        parts = [p.strip()
                 for p in re.split(r'[ ,;]+', port_string) if p.strip()]
        for part in parts:
            try:
                port = int(part)
                if 0 < port < 65536:
                    ports.add(port)
                else:
                    print(
                        f"Warnung: Port {port} außerhalb des gültigen Bereichs (1-65535).")
            except ValueError:
                print(f"Warnung: Ungültige Eingabe '{part}' ignoriert.")
        return sorted(list(ports))

    def _update_ports_from_checkboxes(self):
        checked_ports = set()
        if self.check_var_80.get() == "80":
            checked_ports.add(80)
        if self.check_var_443.get() == "443":
            checked_ports.add(443)
        if self.check_var_8802.get() == "8802":
            checked_ports.add(8802)
        current_ports_in_entry = set(self._get_ports_from_entry())
        manual_ports = current_ports_in_entry - {80, 443, 8802}
        all_ports_to_display = sorted(list(checked_ports.union(manual_ports)))
        self.entry_ports.delete(0, "end")
        self.entry_ports.insert(0, " ".join(map(str, all_ports_to_display)))

    def _update_checkboxes_from_entry(self, event=None):
        current_ports = self._get_ports_from_entry()
        self.check_var_443.set("80" if 80 in current_ports else "off")
        self.check_var_443.set("443" if 443 in current_ports else "off")
        self.check_var_8802.set("8802" if 8802 in current_ports else "off")

    def stop_testing(self):
        if self.test_thread and self.test_thread.is_alive():
            self.stop_event.set()
            self.status_label.configure(text="Stoppe Test...")
        else:
            self.status_label.configure(text="Kein Test aktiv zum Stoppen.")
        self.btn_start.configure(state="normal")
        self.btn_stop.configure(state="disabled")
        self.entry_host.configure(state="normal")
        self.entry_ports.configure(state="normal")
        self.check_80.configure(state="normal")
        self.check_443.configure(state="normal")
        self.check_8802.configure(state="normal")
        if not (self.test_thread and self.test_thread.is_alive()):
            self.status_label.configure(text="Gestoppt.")

    def _run_port_test_loop(self, host, ports):
        test_interval = 5.0
        while not self.stop_event.is_set():
            results = {}
            for port in ports:
                if self.stop_event.is_set():
                    break
                status = self._check_port(host, port)
                results[port] = status
                time.sleep(0.05)
            if not self.stop_event.is_set():
                self.after(0, self._update_result_labels, results)
            self.stop_event.wait(test_interval)
        print("Port Test Loop beendet.")
        self.after(0, self.stop_testing)

    def _check_port(self, host, port, timeout=1.5):
        sock = None
        try:
            addrinfo = socket.getaddrinfo(
                host, port, socket.AF_UNSPEC, socket.SOCK_STREAM)
            family, socktype, proto, canonname, sockaddr = addrinfo[0]
            sock = socket.socket(family, socktype, proto)
            sock.settimeout(timeout)
            result = sock.connect_ex(sockaddr)
            return result == 0
        except socket.gaierror:
            print(f"Fehler: Hostname {host} konnte nicht aufgelöst werden.")
            return None
        except socket.timeout:
            return False
        except Exception as e:
            print(f"Fehler beim Testen von Port {port} auf {host}: {e}")
            return None
        finally:
            if sock:
                sock.close()

    def _update_result_labels(self, results):
        for port, status in results.items():
            label = self.result_labels.get(port)
            if label and label.winfo_exists():
                if status is True:
                    label.configure(text="Offen", fg_color="#28A745")  # Grün
                elif status is False:
                    label.configure(text="Geschlossen",
                                    fg_color="#DC3545")  # Rot
                elif status is None:
                    # Orange/Gelb
                    label.configure(text="Fehler", fg_color="#FFC107")
                else:
                    label.configure(text="Unbekannt", fg_color="grey")

    def destroy(self):
        print("PortTesterTab wird zerstört, stoppe Test...")
        self.stop_event.set()
        if self.test_thread and self.test_thread.is_alive():
            self.test_thread.join(timeout=0.2)
        super().destroy()
